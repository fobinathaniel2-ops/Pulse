import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Palette: Midnight Fjord, Glacier, Lichen, Amber signal, Paper
const ink = Color(0xFF12263A);
const glacier = Color(0xFFDCEBEF);
const lichen = Color(0xFF8FB996);
const amber = Color(0xFFF2A541);
const paper = Color(0xFFF7FAFB);

const bridge = MethodChannel('pulse/native'); // talks to MainActivity.kt

void main() => runApp(const PulseApp());

TextStyle display(double size, Color c) =>
    GoogleFonts.fraunces(fontSize: size, fontWeight: FontWeight.w600, color: c, height: 1.05);

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final scheme = ColorScheme.fromSeed(
    seedColor: ink,
    brightness: b,
    primary: dark ? lichen : ink,
    secondary: amber,
    surface: dark ? const Color(0xFF0C1A28) : paper,
  );
  final base = ThemeData(useMaterial3: true, colorScheme: scheme);
  return base.copyWith(
    scaffoldBackgroundColor: scheme.surface,
    textTheme: GoogleFonts.dmSansTextTheme(base.textTheme),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: dark ? const Color(0xFF12263A) : glacier,
      indicatorColor: dark ? lichen.withOpacity(.3) : Colors.white,
    ),
  );
}

class PulseApp extends StatelessWidget {
  const PulseApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Pulse',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: IndexedStack(index: tab, children: const [TodayPage(), NotesPage(), FeelPage()]),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.battery_charging_full_outlined), label: 'Today'),
            NavigationDestination(icon: Icon(Icons.edit_note), label: 'Notes'),
            NavigationDestination(icon: Icon(Icons.vibration), label: 'Feel'),
          ],
        ),
      );
}

// ---------- Today: battery ring + device facts from Kotlin ----------
class TodayPage extends StatefulWidget {
  const TodayPage({super.key});
  @override
  State<TodayPage> createState() => _TodayPageState();
}

class _TodayPageState extends State<TodayPage> {
  Map<String, dynamic>? bat, dev;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    load();
    timer = Timer.periodic(const Duration(seconds: 5), (_) => load());
  }

  Future<void> load() async {
    try {
      final b = await bridge.invokeMapMethod<String, dynamic>('battery');
      final d = await bridge.invokeMapMethod<String, dynamic>('device');
      if (mounted) setState(() { bat = b; dev = d; });
    } catch (_) {}
  }

  @override
  void dispose() { timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final level = (bat?['level'] ?? 0) as int;
    final charging = bat?['charging'] == true;
    return ListView(padding: const EdgeInsets.all(24), children: [
      Text(charging ? 'Charging,\nsit tight.' : 'Your phone,\nat a glance.', style: display(38, cs.onSurface)),
      const SizedBox(height: 28),
      Center(
        child: SizedBox(
          width: 240, height: 240,
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: level / 100),
            duration: const Duration(milliseconds: 900),
            curve: Curves.easeOutCubic,
            builder: (_, v, __) => CustomPaint(
              painter: Ring(v, level < 20 && !charging ? amber : cs.primary, cs.primary.withOpacity(.12)),
              child: Center(child: Text('$level%', style: display(56, cs.onSurface))),
            ),
          ),
        ),
      ),
      const SizedBox(height: 28),
      fact(cs, 'Device', dev == null ? '…' : '${dev!['maker']} ${dev!['model']}'),
      fact(cs, 'Android', dev == null ? '…' : '${dev!['android']} (API ${dev!['sdk']})'),
      fact(cs, 'Battery temperature', bat == null ? '…' : '${bat!['temp']} °C'),
    ]);
  }

  Widget fact(ColorScheme cs, String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(k, style: TextStyle(color: cs.onSurface.withOpacity(.6))),
          Flexible(child: Text(v, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.w600))),
        ]),
      );
}

class Ring extends CustomPainter {
  final double v;
  final Color fg, bg;
  Ring(this.v, this.fg, this.bg);
  @override
  void paint(Canvas c, Size s) {
    final r = Rect.fromLTWH(10, 10, s.width - 20, s.height - 20);
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..strokeCap = StrokeCap.round
      ..color = bg;
    c.drawArc(r, 0, math.pi * 2, false, p);
    p.color = fg;
    c.drawArc(r, -math.pi / 2, math.pi * 2 * v, false, p);
  }
  @override
  bool shouldRepaint(Ring o) => o.v != v || o.fg != fg;
}

// ---------- Notes: shared_preferences + share_plus ----------
class NotesPage extends StatefulWidget {
  const NotesPage({super.key});
  @override
  State<NotesPage> createState() => _NotesPageState();
}

class _NotesPageState extends State<NotesPage> {
  final ctrl = TextEditingController();
  List<String> notes = [];

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) => setState(() => notes = p.getStringList('notes') ?? []));
  }

  Future<void> save() async => (await SharedPreferences.getInstance()).setStringList('notes', notes);

  void add() {
    final t = ctrl.text.trim();
    if (t.isEmpty) return;
    setState(() => notes.insert(0, t));
    ctrl.clear();
    save();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Notes', style: display(38, cs.onSurface)),
        const SizedBox(height: 16),
        TextField(
          controller: ctrl,
          onSubmitted: (_) => add(),
          decoration: InputDecoration(
            hintText: 'Write something down',
            filled: true,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
            suffixIcon: IconButton(icon: const Icon(Icons.add_circle), onPressed: add),
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: notes.isEmpty
              ? Center(child: Text('Nothing here yet. Add your first note above.',
                  style: TextStyle(color: cs.onSurface.withOpacity(.6))))
              : ListView.builder(
                  itemCount: notes.length,
                  itemBuilder: (_, i) => Dismissible(
                    key: ValueKey('${notes[i]}$i'),
                    onDismissed: (_) { setState(() => notes.removeAt(i)); save(); },
                    background: Container(color: amber.withOpacity(.3)),
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(notes[i]),
                      trailing: IconButton(icon: const Icon(Icons.ios_share), onPressed: () => Share.share(notes[i])),
                    ),
                  ),
                ),
        ),
      ]),
    );
  }
}

// ---------- Feel: Kotlin vibration pads ----------
class FeelPage extends StatelessWidget {
  const FeelPage({super.key});
  static const pads = [('Tap', 20), ('Pulse', 60), ('Thud', 150), ('Rumble', 400)];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Feel it.', style: display(38, cs.onSurface)),
        const SizedBox(height: 8),
        Text('Each pad vibrates your phone for a different length.',
            style: TextStyle(color: cs.onSurface.withOpacity(.6))),
        const SizedBox(height: 20),
        Expanded(
          child: GridView.count(
            crossAxisCount: 2, mainAxisSpacing: 14, crossAxisSpacing: 14,
            children: [
              for (final (name, ms) in pads)
                Material(
                  color: ms == 400 ? amber : cs.primary.withOpacity(.1),
                  borderRadius: BorderRadius.circular(28),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(28),
                    onTap: () => bridge.invokeMethod('buzz', {'ms': ms}),
                    child: Center(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Text(name, style: display(26, ms == 400 ? ink : cs.onSurface)),
                        Text('$ms ms', style: TextStyle(color: (ms == 400 ? ink : cs.onSurface).withOpacity(.6))),
                      ]),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ]),
    );
  }
}
