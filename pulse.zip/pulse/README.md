# Pulse

Flutter UI + Kotlin platform channel + plugins, built to an APK by GitHub Actions.

1. Create a GitHub repo and push this folder's contents.
2. Open the Actions tab, run "Build APK" (or just push).
3. Download `pulse-apk` from the run's Artifacts, unzip, install.

Where things live:
- `src/lib/main.dart`: all UI (three tabs: Today, Notes, Feel)
- `src/MainActivity.kt`: Kotlin code (battery, device info, vibration) reached via the `pulse/native` channel
- `src/pubspec.yaml`: plugins (google_fonts, shared_preferences, share_plus)

To add a native feature: add a `when` branch in MainActivity.kt, call it from Dart with `bridge.invokeMethod('name')`, and add any permission to the `sed` line in the workflow.
